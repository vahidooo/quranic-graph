/**
 * Contains the {@link org.jqurantree.core.error.JQuranTreeException} class and a list of
 * {@link org.jqurantree.core.error.Errors}.
 */
package org.jqurantree.core.error;
