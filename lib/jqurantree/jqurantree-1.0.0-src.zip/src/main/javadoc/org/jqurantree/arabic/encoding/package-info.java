/**
 * Contains interfaces and supporting base classes for Arabic encoders and decoders.
 */
package org.jqurantree.arabic.encoding;
