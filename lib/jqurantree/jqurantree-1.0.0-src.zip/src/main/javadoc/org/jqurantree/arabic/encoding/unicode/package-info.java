/**
 * Contains the {@link org.jqurantree.arabic.encoding.unicode.UnicodeEncoder}
 * and {@link org.jqurantree.arabic.encoding.unicode.UnicodeDecoder}
 * classes for translating {@link org.jqurantree.arabic.ArabicText}
 * to and from Unicode.
 */
package org.jqurantree.arabic.encoding.unicode;
