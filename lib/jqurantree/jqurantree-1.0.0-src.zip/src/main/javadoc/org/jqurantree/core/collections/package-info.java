/**
 * Support package which provides generic iterators
 * for enumerating over immutable collections.
 */
package org.jqurantree.core.collections;
