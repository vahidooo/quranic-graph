/**
 * Contains the {@link org.jqurantree.arabic.encoding.simple.SimpleEncoder}
 * class which implements simple encoding.
 */
package org.jqurantree.arabic.encoding.simple;
