/**
 * Contains the {@link org.jqurantree.analysis.AnalysisTable} class,
 * which is used to tabulate, sort and group results.
 */
package org.jqurantree.analysis;
