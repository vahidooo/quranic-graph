/**
 * Provides classes for reading the Unicode XML source of the orthography model,
 * the Tanzil project's Uthmani distribution.
 */
package org.jqurantree.tanzil;
