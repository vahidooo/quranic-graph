/**
 * Supporting package for accessing embedded JAR resources.
 */
package org.jqurantree.core.resource;
