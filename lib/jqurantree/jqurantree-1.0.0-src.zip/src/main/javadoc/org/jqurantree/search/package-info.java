/**
 * Search API package, providing classes for searching the Holy Quran.
 */
package org.jqurantree.search;
