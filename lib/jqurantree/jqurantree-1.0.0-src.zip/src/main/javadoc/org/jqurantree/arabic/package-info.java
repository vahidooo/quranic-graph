/**
 * Models {@link org.jqurantree.arabic.ArabicText} as a sequence of characters with diacritics,
 * with an internal {@link org.jqurantree.arabic.ByteFormat} used to represent character data.
 */
package org.jqurantree.arabic;
